//
//  LibraryPlaylistsResponse.swift
//  Musicalistic
//
//  Created by Sagar Barvaliya on 2/21/21.
//

import Foundation

struct LibraryPlaylistsResponse: Codable {
    let items: [Playlist]
}
