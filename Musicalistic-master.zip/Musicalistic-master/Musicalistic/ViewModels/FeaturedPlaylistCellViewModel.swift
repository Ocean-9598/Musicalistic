//
//  FeaturedPlaylistCellViewModel.swift
//  Musicalistic
//
//  Created by Sagar Barvaliya on 2/15/21.
//

import Foundation

struct FeaturedPlaylistCellViewModel {
    let name: String
    let artworkURL: URL?
    let creatorName: String
}
