//
//  AlbumCollectionViewCellViewModel.swift
//  Musicalistic
//
//  Created by Sagar Barvaliya on 2/19/21.
//

import Foundation

struct AlbumCollectionViewCellViewModel {
    let name: String
    let artistName: String
}
