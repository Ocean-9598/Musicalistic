//
//  RecommendedTrackCellViewModel.swift
//  Musicalistic
//
//  Created by Sagar Barvaliya on 2/15/21.
//

import Foundation

struct RecommendedTrackCellViewModel {
    let name: String
    let artistName: String
    let artworkURL: URL?
}
