//
//  SearchResultDefaultTableViewCellViewModel.swift
//  Musicalistic
//
//  Created by Sagar Barvaliya on 2/20/21.
//

import Foundation

struct SearchResultDefaultTableViewCellViewModel {
    let title: String
    let imageURL: URL?
}
